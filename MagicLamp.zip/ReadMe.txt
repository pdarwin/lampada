o zip contém 3 ficheiros:
	* MyLamp.bat - executável para Windows (testado em Win 11)
	* MyLamp.jar - executável em java
	* (Aladdin-(Medley-Of-All-Songs).mid - Midi usado no jogo


Para instalar basta descomprimir o zip numa pasta, e correr o ficheiro .bat.
O ficheiro de midi (Aladdin-(Medley-Of-All-Songs).mid) tem de estar na mesma diretoria que o executável. 