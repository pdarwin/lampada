O zip contém 5 ficheiros:
	* MyLamp.bat - executável para Windows (testado em Win 11)
	* MyLamp.jar - executável em java
	* (Aladdin-(Medley-Of-All-Songs).mid - Midi usado no jogo
	* Evil_laugh.wav
	* Demon_dying.wav


Para instalar basta descomprimir o zip numa pasta, e correr o ficheiro .bat.
Os ficheiros de som têm de estar na mesma diretoria que o executável.

Para jogar:
1. Escolher um n.º de 1 a 20, que gerará o máximo de génios dentro da lâmpada
2. Entrando no menu, escolher o n.º de vezes que vai esfregar a lâmpada. 
3. Assim que é esfregada, a lâmpada pergunta-lhe quantos desejos quer realizar
4. O tipo de génio que aparece e o n.º de desejos efetivamente concedidos depende do n.º de vezes que esfregar.
5. É possível ativar e desativar a trilha sonora (Aladino - Arabian Nights).
6. Para sair, use a tecla 3.